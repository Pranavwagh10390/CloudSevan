import { initializeApp } from "firebase/app"
// import "firebase/firebase-storage"
import { getFirestore, serverTimestamp } from "firebase/firestore";
import { getStorage } from 'firebase/storage'
import { getAuth } from "firebase/auth";

const firebaseApp = initializeApp(
  {
    apiKey: "AIzaSyDuQ9WQIjPoF3w9o_aYjwukaFTDNrG2rMw",
    authDomain: "cloudseven-adxfb.firebaseapp.com",
    projectId: "cloudseven-adxfb",
    storageBucket: "cloudseven-adxfb.appspot.com",
    messagingSenderId: "912612240334",
    appId: "1:912612220334:web:bcace5d18d5a9f354fd99f",
    measurementId: "G-8R1H8KKFPM"
  }
);

export const firestore = getFirestore(firebaseApp)
export const auth = getAuth(firebaseApp)
export const storage = getStorage(firebaseApp)
export const db = {
  pizzas: 'allProducts',

  formatedDoc: doc => {
    return { id: doc.id, ...doc.data() }
  },
  getCurrentTimeStamp: serverTimestamp,
}